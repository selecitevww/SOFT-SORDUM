Author: BlueLife , Velociraptor
www.sordum.org

[010101010101010101]--No Mouse Wheel Zoom v1.1--[010101010101010101]

(Wednesday, 19 October 2022)
------------

Changelog:

[FIXED] - Block in All Windows setting was not saved in MWNoZoom.ini file.
[Added] - Block Mouse Wheel option (If this feature is not selected, Left ctrl + mouse wheel will scroll the page without zooming.)
[Added] - Open The properties with Left Mouse click


[010101010101010101]--No Mouse Wheel Zoom v1.0--[010101010101010101]

(Thursday, 27 August 2020)
------------

"No Mouse Wheel Zoom" is a Portable Freeware to avoid accidentally activating zoom function (Usually by using Ctr + mouse wheel)

